package com.SpringBootZuulServer2.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConsumerController {

	//springcloud-zuul-server1和springcloud-zuul-server22将两个服务控制类的接口参数请求和返回值弄成不一样，以便对Zull的功能进行多方面测试
	@RequestMapping("/hi")
    public String index(@RequestParam String name) {
        return name+",hi!";
    }
}
