package com.SpringBootZuulGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

/**
 * Hello world!
 *
 */
@EnableDiscoveryClient
@SpringBootApplication
@EnableZuulProxy
//@EnableZuulProxy是@EnableZuulServer的增强版，当Zuul与Eureka、Ribbon等组件配合使用时，我们使用@EnableZuulProxy
//@EnableZuulProxy开启网关路由服务功能。
//注意：一旦要请求的controller类实现了某个接口，恰好这个接口有自定义的@RequestMapping("/xxx")值，那么在发起请求时，完整的url不能省略这个@RequestMapping值：http://localhost:5555/hello-service/xxx/myHello
public class ZuulGateway 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(ZuulGateway.class, args);
        System.out.println("zuul 服务启动...");
    }
}
